# Flutter UI - Coffee App

[English](README.md)------中文

### 介绍

咖啡应用分为3个页面，分别为闪屏页面、主页面以及登录页面。

### 视频

#### part1

YouTube : [观看地址](https://youtu.be/RNQ1meh9k48)

哔哩哔哩 : [观看地址](https://www.bilibili.com/video/BV1pK411H7uG/)

#### part2

YouTube : [观看地址](https://youtu.be/FmrnHkI3_Ow)

哔哩哔哩 : [观看地址](https://www.bilibili.com/video/BV1Q5411h7o8/)

### 设计 

 - 设计者:  Coffee App Design by [Eman Tawfik](https://dribbble.com/EmanTawfik)



### Coffee App 设计稿

![00](00.png)
![000](000.png)

### Coffee App 最终完成

<div align=center> <img src = '01.png' width = '300' >  <img src = '02.png' width = '300' > <img src = '03.png' width = '300' ></div>


<div align=center> <img src = '001.png' width = '300' >  <img src = '002.png' width = '300' > <img src = '003.png' width = '300' > </div>


