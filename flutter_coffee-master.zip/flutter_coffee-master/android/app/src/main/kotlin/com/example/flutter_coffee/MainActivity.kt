package com.example.flutter_coffee

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
